# We can use either API Keys or Username and Passwords
#   NOTE: You need to set these up on the MongoDB Atlas server and copy them here

# API Keys allow us to use the API without having to log in with an account
#public_key = "????????"
#private_key = "????????-????-????-????-????????????"

# Username and Passwords allow us to log in with an account
username = 'vemularahul23'
password = 'Sai2023'